﻿"use strict";

var connection = new signalR.HubConnectionBuilder().withUrl("/chatHub").configureLogging(signalR.LogLevel.Information).build();

//Disable send button until connection is established
document.getElementById("sendButton").disabled = true;

connection.on("ReceiveMessage", function (user, message) {
    var msg = message.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
    var encodedMsg = user + " says " + msg;
    var li = document.createElement("li");
    li.textContent = encodedMsg;
    document.getElementById("messagesList").appendChild(li);  
});

connection.on("UserIsTyping", function (user, isTyping) {
    document.getElementById('typing_on').innerHTML = isTyping ? user+" is typing...! " : "";
});

connection.start().then(function () {
    document.getElementById("sendButton").disabled = false;
}).catch(function (err) {
    return console.error(err.toString());
});

document.getElementById("sendButton").addEventListener("click", function (event) {
    var user = document.getElementById("userInput").value;
    var message = document.getElementById("messageInput").value;
    connection.invoke("SendMessage", user, message).catch(function (err) {
        return console.error(err.toString());
    });
    event.preventDefault();
});

document.getElementById("messageInput").addEventListener("keyup", function (event) {
    var user = document.getElementById("userInput").value;
    let messageText = messageInput.value;
    connection.invoke("UserIsTyping", user, (messageText != undefined && messageText != null && messageText != "")).catch(function (err) {
        return console.error(err.toString());
    });

    event.preventDefault();
});