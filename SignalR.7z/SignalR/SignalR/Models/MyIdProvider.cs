﻿using Microsoft.AspNet.SignalR;
using Microsoft.AspNet.SignalR.Hubs;
using SignalR.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;

namespace SignalR.Models
{
    public class MyIdProvider : IIdentiryProvider
    {
        public string GetUserId(HubConnectionContext connection)
        {
            // return connection.Clients?.FindFirst(ClaimTypes.Name)?.Value;
            return "ola";
        }
    }
}
