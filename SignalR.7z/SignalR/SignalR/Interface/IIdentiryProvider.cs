﻿using Microsoft.AspNet.SignalR;
using Microsoft.AspNet.SignalR.Hubs;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SignalR.Interface
{
    interface IIdentiryProvider
    {

        string GetUserId(HubConnectionContext connection);

    }

}
