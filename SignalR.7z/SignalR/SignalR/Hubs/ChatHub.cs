﻿using Microsoft.AspNetCore.SignalR;
using System.Threading.Tasks;

namespace SignalRChat.Hubs
{
    //[Authorize]
    public class ChatHub : Hub
    {
        public async Task SendMessage(string user, string message)
        {
            await Clients.All.SendAsync("ReceiveMessage", user, message);
        }

        public async Task UserIsTyping(string user, bool isTyping)
        {
            await Clients.All.SendAsync("UserIsTyping", user, isTyping);
        }

        public void Send(string userId, string message)
        {
            Clients.User(userId).SendAsync(message);
        }
    }
}